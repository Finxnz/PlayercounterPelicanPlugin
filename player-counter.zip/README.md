# Player Counter Plugin - Error Logging Version

## Was wurde hinzugefügt?

Dieses Plugin enthält jetzt **erweiterte Fehlerprotokollierung** und zeigt Fehler **direkt im UI** an!

### 🎯 Fehler werden jetzt angezeigt in:
1. **Widget oben** (wo "Players ? / ?" steht) → Zeigt jetzt "Query Error" mit Details
2. **Tabelle unten** (unter "Error Details") → Zeigt die genaue Fehlermeldung
3. **Laravel Logs** → Detaillierte Debug-Informationen

## 🔍 Wo findest du die Logs?

Die Logs werden in das Laravel-Log-System geschrieben. Du kannst sie hier finden:

### Im Pelican Panel:
1. Öffne dein Pelican Panel
2. Gehe zu den Panel-Logs (meist unter `/var/www/pelican/storage/logs/`)
3. Schaue in die Datei `laravel.log`

### Via SSH:
```bash
tail -f /var/www/pelican/storage/logs/laravel.log | grep PlayerCounter
```

## 📊 Was wird geloggt?

Das Plugin loggt folgende Informationen:

### Bei jedem Query-Versuch:
- **[PlayerCounter] Trying Query Protocol** - Wenn das Query Protocol versucht wird
- **[PlayerCounter] Trying Server List Ping** - Wenn der Server List Ping versucht wird

### Bei Erfolg:
- **[PlayerCounter] Query Protocol successful** - Query hat funktioniert
- **[PlayerCounter] Server List Ping successful** - Ping hat funktioniert

### Bei Fehlern:
- **[PlayerCounter] Query Protocol socket error** - Socket konnte nicht geöffnet werden (mit errno, errstr, IP, Port)
- **[PlayerCounter] Failed to write handshake** - Handshake konnte nicht gesendet werden
- **[PlayerCounter] Query Protocol handshake failed** - Handshake Antwort fehlerhaft
- **[PlayerCounter] Invalid challenge token** - Challenge Token ungültig
- **[PlayerCounter] Query Protocol stat response error** - Stat Response zu kurz
- **[PlayerCounter] Server List Ping socket error** - TCP Socket konnte nicht geöffnet werden
- **[PlayerCounter] Invalid response length** - Ungültige Antwortlänge
- **[PlayerCounter] Empty response** - Leere Antwort erhalten
- **[PlayerCounter] JSON parse error** - JSON konnte nicht geparst werden

## 🎨 UI-Verbesserung

Wenn ein Query fehlschlägt, wird die Fehlermeldung jetzt **direkt im Panel** angezeigt:
- Im **Widget oben**: Roter Block mit "Query Error - Connection Failed" + Fehlermeldung
- In der **Tabelle unten**: "Error Details" mit der genauen Fehlermeldung
- **Offline Server**: Widget zeigt "Server Status - Offline"

## 🐛 Typische Fehler und Lösungen

### "Failed to open UDP socket" (Query Protocol)
**Ursache:** Query Port ist nicht erreichbar oder Query ist im Server deaktiviert
**Lösung:** 
1. Aktiviere Query in der `server.properties`: `enable-query=true`
2. Setze den Query Port: `query.port=25565`
3. Stelle sicher, dass der Port in der Firewall offen ist

### "Failed to open TCP socket" (Server List Ping)
**Ursache:** Server ist offline oder Port ist nicht erreichbar
**Lösung:**
1. Stelle sicher, dass der Server läuft
2. Überprüfe, ob der Port in der Firewall offen ist
3. Teste mit: `telnet <server-ip> <port>`

### "Empty response" / "Timeout"
**Ursache:** Server antwortet nicht innerhalb von 3 Sekunden
**Lösung:**
1. Server könnte überlastet sein
2. Netzwerk-Latenz zu hoch
3. Firewall blockiert Pakete

### "JSON parse error"
**Ursache:** Server sendet ungültige Antwort
**Lösung:**
1. Server-Version ist möglicherweise zu alt oder modifiziert
2. Überprüfe, ob ein Proxy (BungeeCord, Velocity) dazwischen ist

## 🔧 Debug-Modus

Um noch mehr Details zu sehen, kannst du in Laravel den Debug-Modus aktivieren:
1. Öffne `/var/www/pelican/.env`
2. Setze `APP_DEBUG=true`
3. Setze `LOG_LEVEL=debug`

**WICHTIG:** Deaktiviere Debug-Modus wieder in Production!

## ✅ Wie es jetzt funktioniert:

1. **Query Protocol** wird zuerst versucht (vollständige Spielerliste)
2. Wenn das fehlschlägt → **Server List Ping** wird als Fallback verwendet
3. Beide Fehler werden geloggt UND im UI angezeigt
4. Du siehst sofort was schiefgeht, ohne in Logs schauen zu müssen!

## 🆘 Unterstützung

Wenn du immer noch Probleme hast:
1. Schaue im UI nach der Fehlermeldung (direkt sichtbar!)
2. Überprüfe die Logs mit: `tail -f /var/www/pelican/storage/logs/laravel.log | grep PlayerCounter`
3. Teste manuell mit Tools wie `mcstatus` oder `minecraft-query`
4. Überprüfe deine Server-Konfiguration und Firewall
