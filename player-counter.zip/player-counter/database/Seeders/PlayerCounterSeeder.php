<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

/**
 * This seeder is intentionally disabled.
 * No automatic data should be seeded for this plugin.
 * Users must create game queries manually via the Admin Panel.
 */
abstract class PlayerCounterSeeder extends Seeder
{
    public function run(): void
    {
    }
}

