<?php

namespace Finxnz\PlayerCounter\Providers;

use Illuminate\Support\ServiceProvider;

class PlayerCounterPluginProvider extends ServiceProvider
{
    public function register(): void
    {
        // Minimal registration
    }

    public function boot(): void
    {
        // Minimal boot
    }
}
