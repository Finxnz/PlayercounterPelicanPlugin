<?php

namespace Finxnz\PlayerCounter\Models;

use Illuminate\Database\Eloquent\Relations\Pivot;

class EggGameQuery extends Pivot
{
    public $timestamps = false;
}
