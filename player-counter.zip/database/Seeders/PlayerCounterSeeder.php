<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;


abstract class PlayerCounterSeeder extends Seeder
{
    public function run(): void
    {
    }
}

