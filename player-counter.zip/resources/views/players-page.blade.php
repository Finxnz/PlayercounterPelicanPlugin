<x-filament-panels::page>
    <div wire:poll.5s>
        {{ $this->content }}
    </div>
</x-filament-panels::page>
